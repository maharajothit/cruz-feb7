const request = require('request');
console.log("before configModule - process.env.stage = " + process.env.stage);

const uuidV4 = require("uuidv4");

// Configure Environment
const configModule = require('../libs/config-helper.js');
var configuration = configModule.configure(process.env.stage);

const Response = require("../libs/response-lib");

// Declare shared modules
const tokenManager = require('../libs/token-manager.js');
const DynamoDBHelper = require('../libs/dynamodb-helper.js');

// Create a schema
var entitySchema = {
    TableName : configuration.table.entity,
    KeySchema: [
        { AttributeName: "id", KeyType: "HASH"},  //Partition key
        { AttributeName: "id_key", KeyType: "HASH"},  //Partition key
        { AttributeName: "tenant_id_key", KeyType: "RANGE" }  //Sort key
    ],
    AttributeDefinitions: [
        { AttributeName: "id", AttributeType: "S" },
        { AttributeName: "id_key", AttributeType: "N" },        
        { AttributeName: "tenant_id_key", AttributeType: "N" }
    ],
    ProvisionedThroughput: {
        ReadCapacityUnits: 10,
        WriteCapacityUnits: 10
    }
};

class entityMgr {
    constructor(event) {
        this.res = new Response();
        this.bearerToken = event.headers['Authorization'];
        if (this.bearerToken) {
            this.tenantId = tokenManager.getTenantId(event);
        }
    }

    health(event) {
        console.log("User Manager Health Check");
        return new Promise((resolve, reject) => {
            resolve({service: 'User Manager', isAlive: true});
        });
    }

    getEntity(event) {
        return new Promise(function (resolve, reject) {

            console.log('Fetching entity: ' + event.pathParameters.id);

            tokenManager.getCredentialsFromToken(event, function (err,credentials) {
                // init params structure with request params
                var tenantId = tokenManager.getTenantId(event);
                var productId = decodeURIComponent(event.pathParameters.id);
                var params = {
                    tenantId:  tenantId,
                    entityId: entityId
                }
                if (credentials) {

                    // construct the helper object
                    var dynamoHelper = new DynamoDBHelper(entitySchema, credentials, configuration);

                    dynamoHelper.getItem(params, credentials, function (err, entity) {
                        if (err) {
                            console.log('Error getting entity: ' + err.message);
                            reject("Error getting entity");
                        }
                        else {
                            console.log('entity ' + entityId + ' retrieved');
                            resolve(entity);
                        }
                    });
                } else {
                    console.log('Error retrieving credentials: err= ' );
                    console.log(err);
                    reject(err);
                }
            });
        });
    }

    getEntities(event) {

        return new Promise(function (resolve, reject) {
            console.log('Fetching Entities '+ event.pathParameters.id);
            tokenManager.getCredentialsFromToken(event, function (err,credentials) {
                var tenantId = tokenManager.getTenantId(event);

                console.log('Fetching Entity for Tenant Id: ' );
                console.log(tenantId);

                var searchParams = {
                    TableName: entitySchema.TableName,
                    KeyConditionExpression: "tenant_id_key = :tenant_id_key",
                    ExpressionAttributeValues: {
                        ":tenant_id_key": JSON.parse(event.pathParameters.id)
                    }
                };
                console.log("path param---"+JSON.stringify(event.pathParameters.id))
                console.log("==========USER GET USER BY ID searchParams====="+JSON.stringify(event));


                if (credentials) {
                    console.log("searchParams----"+JSON.stringify(searchParams))
                         // construct the helper object
                    var dynamoHelper = new DynamoDBHelper(entitySchema, credentials, configuration);

                    dynamoHelper.query(searchParams, credentials, function (error, entities) {
                        if (error) {
                            console.log('Error retrieving Entities: ' + error.message);
                            reject("Error retrieving Entities");
                        }
                        else {
                            console.log('Entities successfully retrieved');
                            var entityList = { items: entities };
                            console.log(entityList);
                            resolve(entityList);
                        }

                     });
                } else {
                    console.log('Error retrieving credentials: err= ' );
                    console.log(err);
                    reject(err);
                }
            });
        });
    }

    create(event) {

        return new Promise(function (resolve, reject) {
            tokenManager.getCredentialsFromToken(event, function (err,credentials) {
                var entityReq = JSON.parse(event.body);
                if (typeof entityReq === "string") {
                    entityReq = JSON.parse(entityReq); // stringified twice somewhere create object.
                }
                var tenantId = tokenManager.getTenantId(event);

                entityReq.entityId = uuidV4();
                entityReq.tenantId = tenantId;
                if (credentials) {

                    console.log("create: product  ");
                    console.log(entityReq);
                    // construct the helper object
                    var dynamoHelper = new DynamoDBHelper(entitySchema, credentials, configuration);

                    dynamoHelper.putItem(entityReq, credentials, function (err, entity) {
                        if (err) {
                            console.log('Error creating new entity: ' + err.message);
                            reject("Error creating entity");
                        }
                        else {
                            console.log('Entity ' + entityReq.title + ' created');
                            resolve({status: 'success'});
                        }
                    });
                } else {
                    console.log('Error retrieving credentials: err= ' );
                    console.log(err);
                    reject(err);
                }
            });
        });
    }

    update(event) {

        return new Promise(function (resolve, reject) {

            var entityReq = JSON.parse(event.body);
            if (typeof entityReq === "string") {
                entityReq = JSON.parse(entityReq); // stringified twice somewhere create object.
            }

            console.log('Updating product: ' + entityReq.entityId);
            tokenManager.getCredentialsFromToken(event, function (err,credentials) {
                // init the params from the request data
                var tenantId = tokenManager.getTenantId(event);

                var keyParams = {
                    tenantId:  tenantId,
                    entityId: entityReq.entityId
                }
                if (credentials) {

                    console.log('Updating product: ' + entityReq.entityId);

                    var entityUpdateParams = {
                        TableName:                 entitySchema.TableName,
                        Key:                       keyParams,
                        UpdateExpression:          "set " +
                                                       "sku=:sku, " +
                                                       "title=:title, " +
                                                       "description=:description, " +
                                                       "#condition=:condition, " +
                                                       "conditionDescription=:conditionDescription, " +
                                                       "numberInStock=:numberInStock, " +
                                                       "unitCost=:unitCost",
                        ExpressionAttributeNames:  {
                            '#condition': 'condition'
                        },
                        ExpressionAttributeValues: {
                            ":sku":                  productReq.sku,
                            ":title":                productReq.title,
                            ":description":          productReq.description,
                            ":condition":            productReq.condition,
                            ":conditionDescription": productReq.conditionDescription,
                            ":numberInStock":        productReq.numberInStock,
                            ":unitCost":             productReq.unitCost
                        },
                        ReturnValues:              "UPDATED_NEW"
                    };

                    // construct the helper object
                    var dynamoHelper = new DynamoDBHelper(entitySchema, credentials, configuration);

                    dynamoHelper.updateItem(entityUpdateParams, credentials, function (err, entity) {
                        if (err) {
                            console.log('Error updating Entity: ' + err.message);
                            reject("Error updating Entity");
                        }
                        else {
                            console.log('Entity ' + productReq.title + ' updated');
                            resolve(entity);
                        }
                    });
                } else {
                    console.log('Error retrieving credentials: err= ' );
                    console.log(err);
                    reject(err);
                }
            });
        });
    }

    del(event) {

        return new Promise(function (resolve, reject) {
            var entityId = decodeURIComponent(event.pathParameters.id);

            console.log('Deleting product: ' + entityId);

            tokenManager.getCredentialsFromToken(event, function (err,credentials) {
                // init parameter structure
                var tenantId = tokenManager.getTenantId(event);

                var deleteEntityParams = {
                    TableName: entitySchema.TableName,
                    Key:       {
                        tenantId:  tenantId,
                        entityId: entityId
                    }
                };
                if (credentials) {

                    // construct the helper object
                    var dynamoHelper = new DynamoDBHelper(entitySchema, credentials, configuration);

                    dynamoHelper.deleteItem(deleteEntityParams, credentials, function (err, entity) {
                        if (err) {
                            console.log('Error deleting entity: ' + err.message);
                            reject("Error deleting entity");
                        }
                        else {
                            console.log('Entity ' + entityId + ' deleted');
                            resolve({status: 'success'});
                        }
                    });
                } else {
                    console.log('Error retrieving credentials: err= ' );
                    console.log(err);
                    reject(err);
                }
            });
        });
    }
}

module.exports = entityMgr;